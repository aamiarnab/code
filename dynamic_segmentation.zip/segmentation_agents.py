from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import os
from dotenv import load_dotenv
import pandas as pd
import json

import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import plotly.express as px

load_dotenv()

# ---- This is an agent shop for dynamic segmentation -----

# Create the audit log
def create_log(step, step_info, log):
    log[step] = step_info
    return log

def format_log(log):
    prompt = f"Format the log file provided to a better representatoin in html format \
    log: {log} \
    use document theme as audit log document.  Provide only the html string as response"

    response = invoke_llm(prompt)
    response_html = response[7:-4]
    print (response)
    return response_html

# Create human input for llm
# Initialize Gemini model via LangChain
def generate_prompt(persona, objective, additional_context):
    metadata_df = pd.read_csv("hcp_metadata.csv")
    metadata = metadata_df.to_json(orient="records")
    output_instruction = "You are a data scientist who is helping the markting team to \
        identify top 10 most relevant data attribute with maximum influence that are to be used \
        to train an unsupervised ML model for the detail provided for Persona, Objective, Additional context and metadata. \
        Geneate the output in the following format\
        [{feature = column name,\
        influence: (+1 for positive or -1 for negative influence for this objective\
        rationale: why this attibute is relevant for this objective}]\
        Do not list any atrribute that is not present in the metadata"
      
    unit_input = "Personal: " + persona +  " metadata: " + metadata + " Objective: " +  objective + \
        "Additional context: ", additional_context, " Output Instruction: " + output_instruction

    return unit_input

# Invoke llm for a automating identification of features
def suggest_feature(persona, objective, additional_context):
    user_input = generate_prompt(persona, objective, additional_context)

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        google_api_key=os.environ["GOOGLE_API_KEY"]
    )

    # Define prompt template
    prompt = ChatPromptTemplate.from_template(
        "Respond only as per format. Do not add any extra word or character \n\n{input}"
    )

    # Chain: prompt → model → string parser
    chain = prompt | llm | StrOutputParser()

    # Run the chain
    response = chain.invoke({"input": user_input})
    features = json.loads(response[7:-4])

    return features

#Run the segmentation model
def run_segmentation(user_selected_features, context):

    user_selected_features.insert(0,"npi_number")
    hcp_master = pd.read_csv("hcp_master.csv")
    filter = ""
    ranked_df, fig_pca, fig_cluster_dist, fig_cluster_means = kmeans_clustering(user_selected_features)     
    hcp_master_ranked = pd.merge(hcp_master, ranked_df, on='npi_number', how='left')
    #print("hcp_master_ranked : \n", hcp_master_ranked)

    if "oncology" in context.lower():
        filter = "oncology"
    elif "neurology" in context.lower():
        filter = "neurology"
    elif "orthopedics" in context.lower():
        filter = "orthopedics"

    print ("filter :", filter)
    if filter :
        result = hcp_master_ranked[hcp_master_ranked['specialty'].str.lower() == filter]
        #print("result with filter \n" , result)
    else :
        result = hcp_master_ranked
        #print ("result with no filer", result)

    return result, fig_pca, fig_cluster_dist, fig_cluster_means

#K means clustering
def kmeans_clustering(user_selected_features):
    hcp_master = pd.read_csv("hcp_master.csv")
    hcp_master_selected_featue = hcp_master[user_selected_features]
    #print ("hcp_master_selected_featue : \n", hcp_master_selected_featue)

    metadata = pd.read_csv("hcp_metadata.csv")
    for feature in user_selected_features:
        for index, row in metadata.iterrows():
            if feature == row["Attribute Name"] :
                if row["Type"] == "String" :

                    # Encode categorical features
                    df_encoded = pd.get_dummies(hcp_master_selected_featue.drop(feature, axis=1), drop_first=True)
    #print ("df_encoded \n", df_encoded)
    # Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df_encoded)
    # KMeans clustering
    kmeans = KMeans(n_clusters=3, random_state=42)
    hcp_master_selected_featue['Cluster'] = kmeans.fit_predict(X_scaled)
    print ("1 hcp_master_selected_featue \n", hcp_master_selected_featue.head())

    # PCA for visualization
    pca = PCA(n_components=2)
    components = pca.fit_transform(X_scaled)
    hcp_master_selected_featue['PC1'] = components[:, 0]
    hcp_master_selected_featue['PC2'] = components[:, 1]

    # Plot PCA clusters
    fig_pca = px.scatter(
        hcp_master_selected_featue,
        x='PC1',
        y='PC2',
        color='Cluster',
        hover_data=user_selected_features,
        title='PCA Visualization of HCP Clusters',
        template='plotly_white'
    )
    #fig.show()

    # Get cluster centroids
    centroids = kmeans.cluster_centers_

    # Compute distance to assigned cluster centroid
    distances = []
    for i, row in enumerate(X_scaled):
        cluster_id = hcp_master_selected_featue.loc[i, 'Cluster']
        centroid = centroids[cluster_id]
        distance = np.linalg.norm(row - centroid)
        distances.append(distance)

    # Add score column (lower = more central)
    result_attributes = ["npi_number", "Cluster", "PC1", "PC2", "Cluster_Centrality_Score", "Cluster_Rank"]
    hcp_master_selected_featue['Cluster_Centrality_Score'] = distances
    hcp_master_selected_featue['Cluster_Rank'] = hcp_master_selected_featue.groupby('Cluster')['Cluster_Centrality_Score'].rank()
    ranked_df = hcp_master_selected_featue.sort_values(by='Cluster_Rank')[result_attributes]

    ###################
    cluster_counts = hcp_master_selected_featue['Cluster'].value_counts().reset_index()
    cluster_counts.columns = ['Cluster', 'Count']

    fig_cluster_dist = px.bar(cluster_counts, x='Cluster', y='Count', title='Cluster Size Distribution', text='Count')
    #fig_cluster_dist.show()

    cluster_means = pd.DataFrame(centroids, columns=df_encoded.columns)
    cluster_means['Cluster'] = range(len(centroids))

    fig_cluster_means = px.line(cluster_means.melt(id_vars='Cluster'), x='variable', y='value', color='Cluster',
                title='Cluster Centroid Feature Profiles')
    #fig_cluster_means.show()

    ###################
    
    return ranked_df, fig_pca, fig_cluster_dist, fig_cluster_means

# Invoke llm to generate html output
def invoke_llm(user_input):

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        google_api_key=os.environ["GOOGLE_API_KEY"]
    )

    # Define prompt template
    prompt = ChatPromptTemplate.from_template(
        "Respond only as per format suggested. Do not add any extra word or character \n\n{input}"
    )

    # Chain: prompt → model → string parser
    chain = prompt | llm | StrOutputParser()

    # Run the chain
    response = chain.invoke({"input": user_input})
    #print(response)

    return response

def format_output(persona, objective, additional_context, model_result):
    prompt = f"You are a analytics assistant helping to format the data into better presentable format \
        relevant to the input provided in person, objective and addiiontal_context. \
        Show all the columns provided in the data in tabular format, do not change value of the columns . \
        persona : {objective} \
        objective : {objective} \
        additional_context : {additional_context} \
        \
        data: {model_result}\
        \
        Enahnce the content provided into html format for better presentation in the chat window. \
        Highlight important aspects, use commentary as suitable. provide only the html sting as response"

    response = invoke_llm(prompt)
    response_html = response[7:-4]

    return response_html



