import streamlit as st
import streamlit.components.v1 as components

import segmentation_agents as sa
import pandas as pd

# Session state initialization
if "features" not in st.session_state:
    st.session_state.features = []
if "user_selected_features" not in st.session_state:
    st.session_state.user_selected_features = []
if "output" not in st.session_state:
    st.session_state.output = ""
if "persona" not in st.session_state:
    st.session_state.persona = ""
if "objective" not in st.session_state:
    st.session_state.objective = ""
if "additional_context" not in st.session_state:
    st.session_state.additional_context = ""
if "formatted_log" not in st.session_state:
    st.session_state.formatted_log = []
if "model_result" not in st.session_state:
    st.session_state.model_result = pd.DataFrame()
if "fig_heatmap" not in st.session_state:
    st.session_state.fig_heatmap = None
if "fig_pca" not in st.session_state:
    st.session_state.fig_pca = None
if "fig_cluster_dist" not in st.session_state:
    st.session_state.fig_cluster_dist = None
if "fig_cluster_means" not in st.session_state:
    st.session_state.fig_cluster_means = None

log = {}

# -------- Start UI code -------
st.set_page_config(page_title="Dynamic Segmentation", layout="wide")

# Layout: two tabs
tab1, tab2 = st.tabs(["Segmentation Workflow", "Audit Log"])

with tab1:
    col1, col2 = st.columns([1,1])
    with col1:
        st.markdown("### Segmentation purpose")

        # Capturing purpose of segmentation
        persona = st.text_input("Persona", st.session_state.persona)
        st.session_state.persona = persona

        objective = st.text_input("Objective", st.session_state.objective)
        st.session_state.objective = objective

        additional_context = st.text_area("Additional context", st.session_state.additional_context, height=100)
        st.session_state.additional_context = additional_context

        # Logging user input on purpose of segementation
        log = sa.create_log("Step 1", "Capturing purpose of segmentation", log)
        log = sa.create_log("User input provided for persona", st.session_state.persona, log)
        log = sa.create_log("User input provided for objective", st.session_state.objective, log)
        log = sa.create_log("User input provided for additional context", st.session_state.additional_context, log)

        # Step 2 : Call LLM to get features
        if st.button("Suggest Feaures"):
            with st.spinner ("Searching ..."):
                st.session_state.features = sa.suggest_feature(st.session_state.persona, st.session_state.objective, st.session_state.additional_context)
        log = sa.create_log("Step 2", "Creating list of relevant features using LLM", log)
        log = sa.create_log("Relevant features selected by LLM", st.session_state.features, log)

        features = st.session_state.features
        #print("features: ",features)
        user_selected_features = []

        # Step 3 : Feature selection by user
        if features:
            st.markdown("#### Select features to configure segementation model")
            with st.container(height=200):
                for i, feat in enumerate(features):
                    checked = st.checkbox(f"{feat['feature']} ({feat['rationale']})", key =f"feature_{i}")
                    if checked:
                        user_selected_features.append(feat["feature"]) 
                st.session_state.user_selected_features = user_selected_features
                print ("selected feature: ",st.session_state.user_selected_features)

                log = sa.create_log("Step 3", "User selects features", log)
                log = sa.create_log("Features selected by user", user_selected_features, log)
        else:
            st.info("Features will appear after clicking Indentify Features.")

        # Step 4 : Run segmentatoin model
        if st.button("Run Model") and st.session_state.user_selected_features!=[]:
            with st.spinner ("Running model ..."):
                model_result, fig_pca, fig_cluster_dist, fig_cluster_means = sa.run_segmentation(st.session_state.user_selected_features, st.session_state.additional_context)
                st.session_state.model_result = model_result
                st.session_state.fig_pca = fig_pca
                st.session_state.fig_cluster_dist = fig_cluster_dist
                st.session_state.fig_cluster_means = fig_cluster_means
                #display_attributes = ["npi_number", "full_name", "specialty", "location_city", "opt_out_status", "Cluster", "Cluster_Centrality_Score", "Cluster_Rank"]
                display_attributes = ["full_name"] + st.session_state.user_selected_features + ["location_city", "opt_out_status"]
                print("st.session_state.model_result \n", st.session_state.model_result[display_attributes])
                st.session_state.output = sa.format_output(st.session_state.persona, st.session_state.objective, \
                    st.session_state.additional_context, st.session_state.model_result[display_attributes])
                #print ("st.session_state.output \n ", st.session_state.output)
            
            #st.session_state.model_result = " NO MODEL"
        log = sa.create_log("Step 4", "Running segmentatoin model ...", log)
        log = sa.create_log("Model result", st.session_state.model_result.to_json(), log)

    with col2:
        st.markdown("### Recommendation")
        with st.container(height=600):
            st.markdown(st.session_state.output, unsafe_allow_html=True)
        if st.session_state.output:
            left, duffer, right = st.columns([3,3,2])
            with left:
                st.download_button("Download", st.session_state.output, file_name = "output.html")
            with right:
                if st.button("Audit Log"):
                    with st.spinner("Generating log ..."):
                        with open("log_file.txt", "w") as file:
                            file.write(str(log))
                        st.session_state.formatted_log = sa.format_log(str(log))

# ---- Audit log page

with tab2:
    if st.session_state.formatted_log:
        components.html(st.session_state.formatted_log, height=600, scrolling=True)
        #st.markdown(st.session_state.formatted_log, unsafe_allow_html=True)
        col1, col2, col3 = st.columns([1,1,1])
        with col1:
            if st.session_state.fig_pca :
                st.plotly_chart(st.session_state.fig_pca)
        with col2:
            if st.session_state.fig_cluster_dist :
                st.plotly_chart(st.session_state.fig_cluster_dist)
        with col3:
            if st.session_state.fig_cluster_means :
                st.plotly_chart(st.session_state.fig_cluster_means)

    else:
        st.info("No segmentation audit log found")


