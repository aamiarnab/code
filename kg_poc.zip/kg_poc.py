from langchain.chat_models import ChatOpenAI
from langchain.vectorstores import Chroma
from langchain.document_loaders import CSVLoader, PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.agents import Tool, initialize_agent
from langchain.tools import tool
from rdflib import Graph, URIRef, Literal, Namespace, RDF
from neo4j import GraphDatabase
import pandas as pd
import os

from langchain.embeddings import HuggingFaceEmbeddings
from dotenv import load_dotenv
load_dotenv()

# === Setup ===
llm = ChatOpenAI(
    model="gemini-2.0-flash", 
    temperature=0.2,
    openai_api_base="https://generativelanguage.googleapis.com/v1beta/openai/", 
    openai_api_key=os.environ["GOOGLE_API_KEY"]
)

embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"  # Fast and widely used
)

text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)


# === Tool 1: Index CSV or PDF into ChromaDB ===
@tool
def index_documents(input: str) -> str:
    """
    Embeds and indexes CSV or PDF content into ChromaDB.
    Input format: "<path> as <doc_type>", e.g., "prescription_records.csv as csv"
    """
    try:
        source, doc_type = input.strip().rsplit(" as ", 1)
        if doc_type == "csv":
            loader = CSVLoader(file_path=source)
        elif doc_type == "pdf":
            loader = PyPDFLoader(source)
        else:
            return "Unsupported document type"

        docs = loader.load()
        chunks = text_splitter.split_documents(docs)
        db = Chroma.from_documents(documents=chunks, embedding=embedding_model, persist_directory="chroma_index")
        db.persist()
        return f"Indexed {len(chunks)} chunks from {doc_type}"
    except Exception as e:
        return f"Error: {str(e)}"

# === Tool 2: Semantic Search ===
@tool
def semantic_search(query: str) -> str:
    """Performs semantic search over ChromaDB index"""
    db = Chroma(persist_directory="chroma_index", embedding_function=embedding_model)
    results = db.similarity_search(query, k=3)
    return "\n".join([r.page_content for r in results])

# === Tool 3: Generate RDF Triples from CSV ===
@tool
def generate_rdf(input: str) -> str:
    """
    Maps CSV rows to RDF triples using OWL ontology.
    Input format: "<csv_path> using <ontology_path>"
    Example: "data/prescription_records.csv using ontology/medical_ontology.ttl"
    """
    try:
        csv_path, ontology_path = input.strip().rsplit(" using ", 1)
        df = pd.read_csv(csv_path)
        g = Graph()
        ns = Namespace("http://example.org/ontology/")
        g.parse(ontology_path)

        for _, row in df.iterrows():
            subj = URIRef(f"http://example.org/resource/{row['prescription_id']}")
            g.add((subj, RDF.type, ns.Prescription))
            for col in df.columns:
                g.add((subj, ns[col], Literal(row[col])))

        g.serialize("output.ttl", format="turtle")
        return "RDF triples generated and saved to output.ttl"
    except Exception as e:
        return f"Error: {str(e)}"

# === Tool 4: Ingest RDF into Neo4j ===
@tool
def ingest_rdf_to_neo4j(rdf_path: str) -> str:
    """Ingests RDF triples into Neo4j"""
    g = Graph()
    g.parse(rdf_path, format="turtle")
    driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", os.environ["NEO4J_PASSWORD"]))

    with driver.session() as session:
        for s, p, o in g:
            session.run("MERGE (a:Resource {uri: $s}) "
                        "MERGE (b:Resource {uri: $o}) "
                        "MERGE (a)-[:REL {type: $p}]->(b)",
                        {"s": str(s), "p": str(p), "o": str(o)})
    return "RDF triples ingested into Neo4j"

# === Tool 5: Query Neo4j ===
@tool
def query_neo4j(cypher: str) -> str:
    """Executes Cypher query on Neo4j"""
    driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", os.environ["NEO4J_PASSWORD"]))
    with driver.session() as session:
        result = session.run(cypher)
        return str([record.data() for record in result])

# === Tool 6: Load CSV Metadata ===
@tool
def load_csv_metadata(path: str) -> str:
    """Loads CSV and returns column metadata"""
    df = pd.read_csv(path)
    return f"Columns: {list(df.columns)} | Sample: {df.head(2).to_dict()}"

# === Initialize Agent ===
tools = [index_documents, semantic_search, generate_rdf, ingest_rdf_to_neo4j, query_neo4j, load_csv_metadata]
agent = initialize_agent(tools, llm, agent_type="zero-shot-react-description", verbose=True)

if __name__ == "__main__":
    #  Read and index the data
    if not os.path.exists("chroma_index"):
        agent.run("Index the file data/prescription_records.csv as csv")
        agent.run("Index the file pdfs/PT001_medical_notes.pdf as pdf")
        agent.run("Index the file pdfs/PT001_discharge_summary.pdf as pdf")
        agent.run("Index the file pdfs/PT001_clinical_report.pdf as pdf")

    # Generate RDF for Neo4j
    agent.run("Generate RDF triples from data/prescription_records.csv using ontology/medical_ontology.ttl. If you found any issue in the ontology, highlight the so that i can fix it.")
    agent.run("Ingest RDF triples from output.ttl into Neo4j")

    # Run query
    query = "What drugs did Dr. Mehta prescribe to PT001 in October?"
    response = agent.run(query)
    print("\n Response:\n", response)