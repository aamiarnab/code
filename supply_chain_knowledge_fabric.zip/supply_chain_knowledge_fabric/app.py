import streamlit as st
import scm_360_agent as s3a
from langchain.schema import Document


msg=""
if "documents" not in st.session_state:
    st.session_state.documents = []
documents = []
st.set_page_config(page_title="Supplier 360", layout="wide")

tab1, tab2 = st.tabs(["Data Prep", "Talk To Data"])

with tab1:

    # File upload section
    uploaded_file = st.file_uploader(
        "📁 Upload CSV, ZIP",
        type=["csv", "zip"],
        accept_multiple_files=False
    )

    if uploaded_file:
        st.success(f"Uploaded: {uploaded_file.name}")
        # Pass to your existing processing pipeline
        doc = s3a.process_uploaded_file(uploaded_file)  # <-- your existing function
        st.session_state.documents = st.session_state.documents + doc
        print("st.session_state.documents \n", st.session_state.documents)
        #print("documents \n", documents)

    if st.button("Create SCM 360 KF") :
        vectorstore = s3a.build_vector_store(documents)
        st.session_state.documents = []


with tab2:

    st.title("📦 Talk to Data")

    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat history
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    # User input
    user_input = st.chat_input("Ask about shipments, invoices, returns, or labels...")

    if user_input:
        # Add user message to history
        st.session_state.messages.append({"role": "user", "content": user_input})

        # Process query using your existing pipeline
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                response = s3a.process_user_query(user_input)  # <-- your existing function
                st.markdown(response)

        # Add assistant response to history
        st.session_state.messages.append({"role": "assistant", "content": response})