import pandas as pd
import os
import pdfkit

# wkhtmltopdf path
config = pdfkit.configuration(wkhtmltopdf=r"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe")

# Load shipment data
df = pd.read_csv("shipment_log.csv")

# Product catalog
product_catalog = {
    "PRD001": ("Ceftriaxone Injection 1g", 500, 120),
    "PRD002": ("Paracetamol Tablets 500mg", 1000, 2),
    "PRD003": ("Amoxicillin Capsules 250mg", 800, 3),
    "PRD004": ("Azithromycin Tablets 250mg", 600, 5),
    "PRD005": ("Ibuprofen Tablets 400mg", 700, 4),
    "PRD006": ("Metformin Tablets 500mg", 900, 3),
    "PRD007": ("Pantoprazole Tablets 40mg", 750, 6),
    "PRD008": ("Ciprofloxacin Tablets 500mg", 650, 5),
    "PRD009": ("Doxycycline Capsules 100mg", 550, 7),
    "PRD010": ("Levocetirizine Tablets 5mg", 1000, 2),
    "PRD011": ("Losartan Tablets 50mg", 850, 4),
    "PRD012": ("Amlodipine Tablets 5mg", 950, 3),
    "PRD013": ("Atorvastatin Tablets 10mg", 800, 5),
    "PRD014": ("Omeprazole Capsules 20mg", 700, 4),
    "PRD015": ("Hydroxychloroquine Tablets 200mg", 600, 6),
    "PRD016": ("Ranitidine Tablets 150mg", 1000, 2),
    "PRD017": ("Clopidogrel Tablets 75mg", 650, 5),
    "PRD018": ("Enalapril Tablets 5mg", 900, 3),
    "PRD019": ("Fluconazole Tablets 150mg", 500, 8),
    "PRD020": ("Montelukast Tablets 10mg", 950, 4)
}

# Create output folder
os.makedirs("invoices", exist_ok=True)

# Generate invoices
for _, row in df.iterrows():
    product_name, quantity, unit_price = product_catalog[row["ProductID"]]
    total = quantity * unit_price

    html = f"""
    <html>
    <head>
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 50px;
                font-size: 16px;
            }}
            h2 {{
                font-size: 28px;
                font-weight: bold;
                margin-bottom: 20px;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 30px;
            }}
            td {{
                padding: 10px;
                vertical-align: top;
            }}
            .section-title {{
                font-weight: bold;
                font-size: 18px;
                padding-bottom: 5px;
                border-bottom: 2px solid #000;
                margin-top: 30px;
            }}
            .footer {{
                margin-top: 40px;
                font-size: 16px;
            }}
        </style>
    </head>
    <body>
        <h2>Shipment Invoice</h2>

        <div style="margin-bottom: 30px; padding-bottom: 10px; border-bottom: 2px solid #000;">
            <table style="width: 100%;">
                <tr>
                    <td><strong>Invoice #:</strong> INV-{row['ShipmentID'][3:]}</td>
                    <td><strong>Date:</strong> {row['Date']}</td>
                </tr>
            </table>
        </div>
        
        <div class="section-title">Product Description</div>
        <table>
            <tr>
                <td><strong>Batch ID:</strong> {row['BatchID']}</td>
                <td><strong>Product:</strong> {product_name}</td>
            </tr>
            <tr>
                <td><strong>Quantity:</strong> {quantity} units</td>
                <td><strong>Unit Price:</strong> INR {unit_price}</td>
            </tr>
            <tr>
                <td><strong>Total Amount:</strong> INR {total:,}</td>
                <td></td>
            </tr>
        </table>

        <div class="section-title">Shipment Detail</div>
        <table>
            <tr>
                <td><strong>Shipped To:</strong> {row['Destination']} Pharma Depot</td>
                <td><strong>Transport Mode:</strong> Cold Chain</td>
            </tr>
        </table>
    </body>
    </html>
    """

    pdf_filename = f"invoices/invoice_{row['ShipmentID'][3:]}.pdf"
    pdfkit.from_string(html, pdf_filename, configuration=config)