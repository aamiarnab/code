import os
import streamlit as st

from langchain.document_loaders import CSVLoader, UnstructuredPDFLoader
from langchain_community.document_loaders.image import UnstructuredImageLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv


# -----------------------------
# 🔐 Environment Setup
# -----------------------------
load_dotenv()
#os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY  # Replace with your actual key

# -----------------------------
# 📥 Load and Chunk Documents
# -----------------------------
def load_documents():
    shipment_docs = CSVLoader("shipment_log.csv").load()
    return_docs = CSVLoader("return_notes.csv").load()
    invoice_docs = UnstructuredPDFLoader("invoice_1234.pdf").load()
    label_docs = UnstructuredImageLoader("label_5678.png").load()
    print("label_docs \ n", label_docs)
    #text = pytesseract.image_to_string(label_docs)

    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    return splitter.split_documents(shipment_docs + return_docs + invoice_docs + label_docs)

# -----------------------------
# 🧠 Embed and Index with ChromaDB
# -----------------------------
def build_vector_store(docs):
    embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    vectorstore = Chroma.from_documents(docs, embedding_model, persist_directory="./chroma_store")
    return vectorstore

# -----------------------------
# 🔮 Gemini 2.0 Flash LLM
# -----------------------------
def build_qa_chain(vectorstore):
    llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.2)
    return RetrievalQA.from_chain_type(llm=llm, retriever=vectorstore.as_retriever())

# -----------------------------
# 💬 Streamlit UI
# -----------------------------
def main():
    st.set_page_config(page_title="Pharma Supply Chain Chat", layout="wide")
    st.title("💬 Pharma Supply Chain Knowledge Fabric")

    with st.spinner("Loading and indexing documents..."):
        docs = load_documents()
        #print("docs \n", docs)
        vectorstore = build_vector_store(docs)
        embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        vectorstore = Chroma(collection_name="langchain", embedding_function=embedding_model,persist_directory="./chroma_store") 
        #results = vectorstore.similarity_search(query=query,k=5)

        qa_chain = build_qa_chain(vectorstore)

    query = st.text_input("Ask about shipments, returns, invoices...")

    if query:
        with st.spinner("Thinking..."):
            response = qa_chain.run(query)
        st.markdown("### 📌 Response")
        st.write(response)

if __name__ == "__main__":
    main()