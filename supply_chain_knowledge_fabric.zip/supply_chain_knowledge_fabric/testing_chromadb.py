
def count_collections():
    import chromadb 
    from chromadb.config import Settings

    # Initialize ChromaDB client
    #client = chromadb.Client(Settings(persist_directory="./chroma_store"))
    client = chromadb.PersistentClient(path="./chroma_store") 
    collections = client.list_collections()
    for collection in collections:
        collection_name = collection.name
        num_docs = collection.count()
        print(f"Collection: {collection_name}, Number of Documents: {num_docs}")
    return collection_name, num_docs

#collection = client.get_collection(name="langchain")
#print(collection.get())
#print(count_collections())


def load_pdf():
    from langchain.document_loaders import CSVLoader, UnstructuredPDFLoader
    from langchain_community.document_loaders.image import UnstructuredImageLoader

    invoice_docs = UnstructuredPDFLoader("invoices\invoice_001.pdf").load()
    print(invoice_docs)
    for doc in invoice_docs:
        InvoiceID = doc.page_content.split("Invoice #: ")[1][:7].strip()  
        doc.metadata["InvoiceID"] = InvoiceID
        BatchID = doc.page_content.split("Batch ID: ")[1][:6].strip()  
        doc.metadata["BatchID"] = BatchID
        print(BatchID)
    #print(docs)
load_pdf()

