import os
from pydoc import Doc
import streamlit as st

from langchain.document_loaders import CSVLoader, UnstructuredPDFLoader
from langchain_community.document_loaders.image import UnstructuredImageLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

import zipfile
import os
import tempfile
from pypdf import PdfReader


# -----------------------------
# 🔐 Environment Setup
# -----------------------------
load_dotenv()
#os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY  # Replace with your actual key

# -----------------------------
# 📥 Load and Chunk Documents
# -----------------------------

def process_uploaded_file(uploaded_file):
    docs = []
    uploaded_file_type = uploaded_file.name[-3:]
    if uploaded_file_type == "csv" :
        if uploaded_file.name == "shipment_log.csv":
            shipdocs = CSVLoader("shipment_log.csv").load()
            for doc in shipdocs:
                print("shipment log doc \n", doc)
                doc.metadata["ShipmentID"] = get_metadata(doc.page_content, "ShipmentID")
                doc.metadata["BatchID"] = get_metadata(doc.page_content, "BatchID")
                doc.metadata["source"] = "Shipment Log"
                docs.append(doc)
        elif uploaded_file.name == "return_notes.csv":
            returndocs = CSVLoader("return_notes.csv").load()
            for doc in returndocs:
                doc.metadata["ShipmentID"] = get_metadata(doc.page_content, "ShipmentID")
                doc.metadata["ReturnID"] = get_metadata(doc.page_content, "ReturnID")
                doc.metadata["source"] = "Return Notes"
                docs.append(doc)
    elif uploaded_file_type == "zip" :
        docs = zip_to_doc(uploaded_file)
    else :
        print("Please upload only .csv or .zip files") 
    return docs


# Get metadata from document
def get_metadata(page_content, metadata_name):
    metadata = {}
    for line in page_content.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip()

    return metadata.get(metadata_name)




# Agent reads a zip of pdf or png files and convert them into a langchain doc ready to be merged with knowledge fabric
def zip_to_doc(uploaded_file):
    with tempfile.TemporaryDirectory() as temp_dir:
        zip_path = os.path.join(temp_dir, "uploaded.zip")
        with open(zip_path, "wb") as f:
            f.write(uploaded_file.read())

        # Extract ZIP contents
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(temp_dir)

        # Find all PDF files
        pdf_files = [os.path.join(temp_dir, f) for f in os.listdir(temp_dir) if f.lower().endswith(".pdf")]
        png_files = [os.path.join(temp_dir, f) for f in os.listdir(temp_dir) if f.lower().endswith(".png")]
        documents = []

        if pdf_files :
            for pdf_path in pdf_files:
                try:
                    invoice_docs = UnstructuredPDFLoader(pdf_path).load()
                    for doc in invoice_docs:
                        doc.metadata["InvoiceID"] = get_metadata(doc.page_content, "Invoice #")
                        doc.metadata["BatchID"] = get_metadata(doc.page_content, "Batch ID")
                        doc.metadata["source"] = "Invoice Pdf"
                        print("invoice doc", doc[0].page_content)
                        documents.append(doc[0])
                except Exception as e:
                    print(f"Error processing {os.path.basename(pdf_path)}: {e}")
            
        elif png_files :
            for png_path in png_files:
                print("png_path : ", png_path)
                try:
                    label_docs = UnstructuredImageLoader(png_path).load()
                    for doc in label_docs:
                        #BatchID = doc.page_content.split("Batch ")[1][:6].strip()  
                        doc.metadata["source"] = "Label Image"
                        print("label_docs \n", doc[0].page_content )
                        #print(BatchID, doc)
                        documents.append(doc[0])

                except Exception as e:
                    print(f"Error processing {os.path.basename(png_path)}: {e}")

        else:
            print("No PDF or PNG files found in the ZIP.")

    return documents


# -----------------------------
# 🧠 Embed and Index with ChromaDB
# -----------------------------
def build_vector_store(docs):
    embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    vectorstore = Chroma.from_documents(docs, embedding_model, persist_directory="./chroma_store")
    return vectorstore

# Agent to process user query fo the talk to data 

def process_user_query(user_input):
    return None

# -----------------------------
# 🔮 Gemini 2.0 Flash LLM
# -----------------------------
def build_qa_chain(vectorstore):
    llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.2)
    return RetrievalQA.from_chain_type(llm=llm, retriever=vectorstore.as_retriever())


# -----------------------------
# 💬 Streamlit UI
# -----------------------------
def main():
    st.set_page_config(page_title="Pharma Supply Chain Chat", layout="wide")
    st.title("💬 Pharma Supply Chain Knowledge Fabric")

    with st.spinner("Loading and indexing documents..."):
        docs = load_documents()
        #print("docs \n", docs)
        vectorstore = build_vector_store(docs)
        embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        vectorstore = Chroma(collection_name="langchain", embedding_function=embedding_model,persist_directory="./chroma_store") 
        #results = vectorstore.similarity_search(query=query,k=5)

        qa_chain = build_qa_chain(vectorstore)

    query = st.text_input("Ask about shipments, returns, invoices...")

    if query:
        with st.spinner("Thinking..."):
            response = qa_chain.run(query)
        st.markdown("### 📌 Response")
        st.write(response)

"""if __name__ == "__main__":
    main()''"""

############### Duplicate remove 
def load_documents():
    shipment_docs = CSVLoader("shipment_log.csv").load()
    return_docs = CSVLoader("return_notes.csv").load()
    invoice_docs = UnstructuredPDFLoader("invoice_1234.pdf").load()
    label_docs = UnstructuredImageLoader("label_5678.png").load()
    print("label_docs \ n", label_docs)
    #text = pytesseract.image_to_string(label_docs)

    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    return splitter.split_documents(shipment_docs + return_docs + invoice_docs + label_docs)
