from nt import pipe
import os
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import os
from dotenv import load_dotenv
import json

load_dotenv()

def generate_impact_assement_report(change, codebase):
    style_sheet = style()
    prompt = f"You are a data pipeline assistant who is helping to carry out impact assessemnt on \
        piple codebase due to change in data schema  \
        The pipeline codebase is provided as codebase, it can be written in python, sql or other programing language\
        You will scan the pipeline code, check for possible impact due the source schema change \
        source schema change: {change} \
        codebase: {codebase} \
        style sheet : {style_sheet} \
        Output will consist with three sections \
        Summary of change : This section will summarize the change required in the codebase \
        Suggested code change : This section will detail the changes requried in paragraph for each code file  \
            and for impacted each code section or function only. \
            mentioning reason for impact and highliting lines of code needed change \
            If not change is required for a section or function, just mention no impact. \
        Suggested test cases : This section will list the test cases to be executed for the modified code. \
        Enahnce the output content into html format using style sheet provided for better presentation \
        use document theme as technical design document. Provide only the html string as response"

    response = invoke_llm(prompt)
    response_html = response[7:-4]

    return response_html


# Invoke llm to generate html output
def invoke_llm(user_input):

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        google_api_key=os.environ["GOOGLE_API_KEY"]
    )

    # Define prompt template
    prompt = ChatPromptTemplate.from_template(
        "Respond only as per format suggested. Do not add any extra word or character \n\n{input}"
    )

    # Chain: prompt → model → string parser
    chain = prompt | llm | StrOutputParser()

    # Run the chain
    response = chain.invoke({"input": user_input})
    print(response)

    return response

# Read codebase
def read_files_in_directory(directory_path):
    pipeline_code = {}
    try:
        # List all entries in the directory
        for entry_name in os.listdir(directory_path):
            file_path = os.path.join(directory_path, entry_name)

            # Check if the entry is a file (and not a directory)
            if os.path.isfile(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8') as file:
                        content = file.read()
                        pipeline_code[entry_name] = content
                except Exception as e:
                    print(f"Error reading file {entry_name}: {e}")
                print("-" * 30) # Separator
            else:
                print(f"Skipping directory/non-file entry: {entry_name}")

    except FileNotFoundError:
        print(f"Error: Directory not found at '{directory_path}'")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    
    return pipeline_code

# Read uploaded code
def read_uploaded_code(uploaded_file):
    bytes_data = uploaded_file.getvalue()
    content = bytes_data.decode("utf-8")
    return content

# Convert html to pdf
import pdfkit

def convert_html_to_pdf(html_string, output_pdf_path):
    config = pdfkit.configuration(wkhtmltopdf=r"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe")
    try:
        #pdfkit.from_string(html_string, output_pdf_path)
        pdfkit.from_string(html_string, output_pdf_path, configuration=config)

        print(f"PDF saved to {output_pdf_path}")
    except Exception as e:
        print(f"Error converting to PDF: {e}")


def style():
    style = """
<style>
body {
font-family: Arial, sans-serif;
line-height: 1.6;
margin: 20px;
}
h1, h2, h3 {
color: #333;
}
.summary {
background-color: #f8f8f8;
padding: 15px;
border: 1px solid #ddd;
margin-bottom: 20px;
}
.code-changes {
margin-bottom: 20px;
}
.file-name {
font-weight: bold;
margin-bottom: 5px;
}
.section-title {
font-style: italic;
margin-bottom: 5px;
}
.impact-reason {
color: #888;
margin-bottom: 5px;
}
.code-block {
background-color: #eee;
padding: 10px;
border: 1px solid #ccc;
margin-bottom: 10px;
white-space: pre-wrap;
}
.test-cases {
margin-bottom: 20px;
}
.test-case-item {
margin-bottom: 5px;
}
.highlight {
background-color: yellow;
}
</style>
"""

    return style


##### Backup codes

def backup_generate_impact_assement_report(change, codebase):
    style_sheet = style()
    prompt = f"You are a data pipeline assistant who is helping to carry out impact assessemnt on \
        piple codebase due to change in data schema  \
        The pipeline codebase is provided as codebase, it can be written in python, sql or other programing language\
        You will scan the pipeline code, check for possible impact due the change, and generate output \
        using the style sheet provided as style \
        change: {change} \
        codebase: {codebase} \
        style sheet : {style_sheet} \
        Output will consist with three sections \
        Summary of change : This section will summarize the change required in the codebase \
        Suggested code change : This section will detail the changes requried in paragraph for each code file  \
            further broken into each code section or function with possible impact, reason for impact, \
            previous code block, suggested modified code block. \
            If not change is required for a code component, \
            dont generate previous or suggested modified code block for the same\
        Suggested test cases : This section will list the test cases to be executed for the modified code. \
        Enahnce the output content into html format for better presentation as a technical design document \
        highlighting important aspects. Provide only the html string as response"

    response = invoke_llm(prompt)
    response_html = response[7:-4]

    return response_html

