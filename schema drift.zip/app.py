import schema_drift_checks_agents as sda
import streamlit as st
import streamlit.components.v1 as components

st.markdown("""
    <style>
        /* Remove Streamlit header */
        header {visibility: hidden;}
        /* Remove Streamlit footer */
        footer {visibility: hidden;}
        /* Remove hamburger menu and collapse sidebar space */
        [data-testid="stSidebarNav"] {display: none;}
        [data-testid="collapsedControl"] {display: none;}

        /* Reclaim space from header */
        .block-container {
            padding-top: 1rem;
        }

        /* Optional: remove top margin from main content */
        .main {
            margin-top: 0px;
        }
    </style>
""", unsafe_allow_html=True)


# Set page config
st.set_page_config(page_title="Impact Assessment", layout="wide")
msg=""
if "change_desc" not in st.session_state:
    st.session_state.change_desc = ""
if "uploaded_file_content" not in st.session_state:
    st.session_state.uploaded_file_content = ""
if "assement_input" not in st.session_state:
    st.session_state.assement_input = "" 
if "output" not in st.session_state:
    st.session_state.output = ""
if "content" not in st.session_state:
    st.session_state.content = ""
if "report_ready" not in st.session_state:
    st.session_state.report_ready = False

# Tabs
tab1, tab2 = st.tabs(["📁 Impact Assessment", ""])

with tab1:
    st.markdown("### Data pipeline impact assessment ")
    col1, col2 = st.columns([3,1])
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)  
        start_button = st.button("Start Assessment")
        st.markdown("-------------------------")
        log_container = st.container()

    with col1:
        code_diretory = st.text_input(r"$\normalsize{\textsf{Enter code diretory:}}$")
        change_desc = st.text_area(r"$\normalsize{\textsf{Enter change detail:}}$", height=110)
        st.session_state.change_desc = change_desc

    if st.session_state.change_desc != "" and start_button:
        log_container.markdown("Reading current codebase")
        code_directory = ".\pipeline_code"
        codebase = sda.read_files_in_directory(code_directory)
        with st.spinner("Generating report ... "):
            st.session_state.content = sda.generate_impact_assement_report(st.session_state.change_desc, codebase)

        #st.session_state.output.markdown(content, unsafe_allow_html=True)
        log_container.markdown("Assement report generated")
        #if st.session_state.content:
    else:
        log_container.markdown("Pleaes provide the change detail")

    if st.session_state.content:
        st.markdown("#### Assessment Report ")
        st.session_state.output = st.container(height=400)

        with st.session_state.output:
            components.html(st.session_state.content, height=600, scrolling=True)

        left, buffer, right = st.columns([3,5,2])
        with left:
            st.download_button("Downlaod HTML", st.session_state.content, file_name = "Assessment_Report.html")
        with right:
            if st.button("Download Pdf"):
                sda.convert_html_to_pdf(st.session_state.content, "Assess Report.pdf")       

