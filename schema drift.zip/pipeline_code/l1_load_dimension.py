# ============================================
# Section 1: Imports and Setup
# ============================================
import pandas as pd
import logging
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError

# Configure logging
logging.basicConfig(
    filename='dimension_load.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# MySQL connection setup
MYSQL_USER = 'your_username'
MYSQL_PASSWORD = 'your_password'
MYSQL_HOST = 'localhost'
MYSQL_PORT = '3306'
MYSQL_DB = 'your_database'

engine = create_engine(f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}')

# ============================================
# Section 2: Utility Function for Audit Fields
# ============================================
def add_audit_fields(df):
    now = datetime.now()
    df['insert_date'] = now
    df['update_date'] = now
    df['latest_record_flag'] = True
    return df

# ============================================
# Section 3: Load l1_order_dim
# Description: Joins order and order_line tables
# ============================================
def l1_order_dim_load():
    try:
        order_df = pd.read_sql('SELECT * FROM `order`', con=engine)
        line_df = pd.read_sql('SELECT * FROM order_line', con=engine)

        merged_df = pd.merge(order_df, line_df, on='order_id', how='inner')
        final_df = add_audit_fields(merged_df)

        final_df.to_sql('l1_order_dim', con=engine, if_exists='replace', index=False)
        logging.info(f"l1_order_dim loaded with {len(final_df)} records.")

    except SQLAlchemyError as e:
        logging.error(f"MySQL error in l1_order_dim_load: {str(e)}")
    except Exception as e:
        logging.error(f"Unexpected error in l1_order_dim_load: {str(e)}")

# ============================================
# Section 4: Load l1_shipment_dim
# Description: Joins shipment, return, and return_reason_ref tables
# ============================================
def l1_shipment_dim_load():
    try:
        shipment_df = pd.read_sql('SELECT * FROM shipment', con=engine)
        return_df = pd.read_sql('SELECT * FROM `return`', con=engine)
        reason_df = pd.read_sql('SELECT * FROM return_reason_ref', con=engine)

        merged_df = pd.merge(shipment_df, return_df, on='shipment_id', how='left')
        merged_df = pd.merge(merged_df, reason_df, on='return_reason_code', how='left')
        final_df = add_audit_fields(merged_df)

        final_df.to_sql('l1_shipment_dim', con=engine, if_exists='replace', index=False)
        logging.info(f"l1_shipment_dim loaded with {len(final_df)} records.")

    except SQLAlchemyError as e:
        logging.error(f"MySQL error in l1_shipment_dim_load: {str(e)}")
    except Exception as e:
        logging.error(f"Unexpected error in l1_shipment_dim_load: {str(e)}")

# ============================================
# Section 5: Load l1_product_dim
# Description: Loads product table with audit fields
# ============================================
def l1_product_dim_load():
    try:
        df = pd.read_sql('SELECT * FROM product', con=engine)
        final_df = add_audit_fields(df)

        final_df.to_sql('l1_product_dim', con=engine, if_exists='replace', index=False)
        logging.info(f"l1_product_dim loaded with {len(final_df)} records.")

    except SQLAlchemyError as e:
        logging.error(f"MySQL error in l1_product_dim_load: {str(e)}")
    except Exception as e:
        logging.error(f"Unexpected error in l1_product_dim_load: {str(e)}")

# ============================================
# Section 6: Load l1_customer_dim
# Description: Loads customer table with audit fields
# ============================================
def l1_customer_dim_load():
    try:
        df = pd.read_sql('SELECT * FROM customer', con=engine)
        final_df = add_audit_fields(df)

        final_df.to_sql('l1_customer_dim', con=engine, if_exists='replace', index=False)
        logging.info(f"l1_customer_dim loaded with {len(final_df)} records.")

    except SQLAlchemyError as e:
        logging.error(f"MySQL error in l1_customer_dim_load: {str(e)}")
    except Exception as e:
        logging.error(f"Unexpected error in l1_customer_dim_load: {str(e)}")

# ============================================
# Section 7: Main Execution
# ============================================
if __name__ == '__main__':
    logging.info("Starting dimension table loads...")

    l1_order_dim_load()
    l1_shipment_dim_load()
    l1_product_dim_load()
    l1_customer_dim_load()

    logging.info("Dimension table loads completed.")
