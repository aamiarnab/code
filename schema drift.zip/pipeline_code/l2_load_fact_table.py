# ============================================
# Section 1: Imports and Setup
# ============================================
import pandas as pd
import logging
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError

# Configure logging
logging.basicConfig(
    filename='fact_table_load.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# MySQL connection setup
MYSQL_USER = 'your_username'
MYSQL_PASSWORD = 'your_password'
MYSQL_HOST = 'localhost'
MYSQL_PORT = '3306'
MYSQL_DB = 'your_database'

engine = create_engine(f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}')

# ============================================
# Section 2: Load and Transform Fact Data
# ============================================
def load_fact_order_summary():
    try:
        # Load dimension tables
        order_df = pd.read_sql('SELECT order_id, customer_id, drug_id, shipment_id, order_date, total_amount, quantity_ordered FROM l1_order_dim', con=engine)
        time_df = pd.read_sql('SELECT date_key, full_date FROM dim_time', con=engine)

        # Join with time dimension
        merged_df = pd.merge(order_df, time_df, left_on='order_date', right_on='full_date', how='left')

        # Aggregate measures
        agg_df = merged_df.groupby(['order_id', 'customer_id', 'drug_id', 'shipment_id', 'date_key']).agg({
            'total_amount': 'sum',
            'quantity_ordered': 'sum'
        }).reset_index()

        agg_df.rename(columns={
            'total_amount': 'total_order_value',
            'quantity_ordered': 'total_quantity'
        }, inplace=True)

        # Add audit fields
        now = datetime.now()
        agg_df['insert_date'] = now
        agg_df['update_date'] = now
        agg_df['latest_record_flag'] = True

        # Final selection
        fact_df = agg_df[[
            'order_id',
            'customer_id',
            'drug_id',
            'shipment_id',
            'date_key',
            'total_order_value',
            'total_quantity',
            'insert_date',
            'update_date',
            'latest_record_flag'
        ]]

        # Load to MySQL
        fact_df.to_sql('fact_order_summary', con=engine, if_exists='replace', index=False)
        logging.info(f"fact_order_summary loaded with {len(fact_df)} records.")

    except SQLAlchemyError as e:
        logging.error(f"MySQL error in load_fact_order_summary: {str(e)}")
    except Exception as e:
        logging.error(f"Unexpected error in load_fact_order_summary: {str(e)}")

# ============================================
# Section 3: Main Execution
# ============================================
if __name__ == '__main__':
    logging.info("Starting fact_order_summary load...")
    load_fact_order_summary()
    logging.info("Fact table load completed.")
