# ===============================
# Section 1: Imports and Setup
# ===============================
import pandas as pd
import logging
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError

# Configure logging
logging.basicConfig(
    filename='data_ingestion.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# MySQL connection setup
MYSQL_USER = 'your_username'
MYSQL_PASSWORD = 'your_password'
MYSQL_HOST = 'localhost'
MYSQL_PORT = '3306'
MYSQL_DB = 'your_database'

engine = create_engine(f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}')

# ===============================
# Section 2: Utility Function
# ===============================
def load_csv_to_mysql(file_path, table_name, parse_dates=None, dtype=None, dedup_key=None):
    try:
        df = pd.read_csv(file_path, parse_dates=parse_dates, dtype=dtype)

        # Deduplication logic if primary key is provided
        if dedup_key:
            df.drop_duplicates(subset=dedup_key, inplace=True)

        # Append to existing table (incremental load)
        df.to_sql(table_name, con=engine, if_exists='append', index=False)
        logging.info(f"Successfully loaded {len(df)} records into '{table_name}' from '{file_path}'.")

    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
    except SQLAlchemyError as e:
        logging.error(f"MySQL error while loading '{file_path}' into '{table_name}': {str(e)}")
    except Exception as e:
        logging.error(f"Unexpected error in '{table_name}' load: {str(e)}")

# ===============================
# Section 3: Table Load Functions
# ===============================

def l0_order_load():
    load_csv_to_mysql(
        file_path='scm_order_extract.csv',
        table_name='order',
        parse_dates=['order_date'],
        dedup_key='order_id'
    )

def l0_order_line_load():
    load_csv_to_mysql(
        file_path='scm_order_line_extract.csv',
        table_name='order_line',
        dedup_key='line_item_id'
    )

def l0_shipment_load():
    load_csv_to_mysql(
        file_path='scm_shipment_extract.csv',
        table_name='shipment',
        parse_dates=['shipment_date'],
        dtype={'cold_chain_flag': bool},
        dedup_key='shipment_id'
    )

def l0_return_load():
    load_csv_to_mysql(
        file_path='scm_return_extract.csv',
        table_name='return',
        parse_dates=['return_date'],
        dedup_key='return_id'
    )

def l0_product_load():
    load_csv_to_mysql(
        file_path='scm_product_extract.csv',
        table_name='product',
        dtype={'controlled_substance_flag': bool},
        dedup_key='drug_id'
    )

def l0_customer_load():
    load_csv_to_mysql(
        file_path='scm_customer_extract.csv',
        table_name='customer',
        dedup_key='customer_id'
    )

def l0_return_reason_ref_load():
    load_csv_to_mysql(
        file_path='scm_return_reason_ref_extract.csv',
        table_name='return_reason_ref',
        dedup_key='return_reason_code'
    )

# ===============================
# Section 4: Main Execution
# ===============================
if __name__ == '__main__':
    logging.info("Starting data ingestion process...")

    l0_order_load()
    l0_order_line_load()
    l0_shipment_load()
    l0_return_load()
    l0_product_load()
    l0_customer_load()
    l0_return_reason_ref_load()

    logging.info("Data ingestion process completed.")
