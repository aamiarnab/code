# convert_csv_to_json.py
import pandas as pd
import json

def csv_to_json(csv_path):
    df = pd.read_csv(csv_path)
    grouped = df.groupby("Table Name")
    schema = {}
    for table, group in grouped:
        schema[table] = []
        for _, row in group.iterrows():
            schema[table].append({
                "column": row["Column Name"],
                "type": row["Data Type"],
                "description": row["Description"]
            })
    return schema

# Example usage
#schema_json = csv_to_json("veeva_crm_metadata.csv")
# with open("crm_schema.json", "w") as f:
#     json.dump(schema_json, f, indent=2)

# relationship.py

crm_relationships = [
    # CRM Core
    ("Account", "Address"),
    ("Account", "Territory2"),
    ("Territory2", "TSF"),
    ("TSF", "Account"),
    ("User", "Call"),
    ("User", "Event"),
    ("Account", "Call"),
    ("Call", "Call2_Detail"),
    ("Call", "Call2_Sample"),
    ("Call", "Call2_Key_Message"),
    ("Call", "Product"),
    ("Account", "Consent"),
    ("Account", "Transfer_of_Value__c"),
    ("Account", "Event_Attendee"),
    ("Event_Attendee", "Event"),
    ("Event", "Product"),
    ("Account", "Sample_Order__c"),
    ("Account", "Order__c"),
    ("Account", "Medical_Inquiry__c"),
    ("Account", "Digital_Engagement__c"),
    ("Account", "Activity_History"),

    # Order Management
    ("hcp_account", "order_header"),
    ("order_header", "order_line"),
    ("order_line", "Product"),
    ("order_header", "shipment"),
    ("shipment", "shipment_line"),
    ("shipment_line", "Product"),
    ("order_header", "invoice"),
    ("invoice", "payment"),
    ("order_header", "order_status_history"),
    ("order_header", "sample_order"),
    ("Product", "controlled_substance_flag"),
    ("order_header", "order_compliance_check"),
    ("Product", "product_pricing"),
    ("hcp_account", "hcp_license_validation"),
    ("order_header", "order_channel"),
    ("order_header", "return_order"),
    ("order_header", "order_attachment"),
    ("Product", "inventory_balance"),
    ("inventory_balance", "inventory_location"),

    # Sales Planning
    ("sales_plan", "sales_target"),
    ("sales_target", "call_plan"),
    ("sales_target", "segmentation"),
    ("sales_target", "reach_frequency"),
    ("sales_plan", "sales_forecast"),

    # Medical Events
    ("Event", "event_product"),
    ("Event", "event_feedback"),
    ("Event", "advisory_board"),
    ("Event", "speaker_program"),
    ("Account", "msl_interaction"),
    ("Account", "clinical_trial_participation"),

    # Surveys
    ("hcp_survey", "survey_response"),
    ("survey_response", "Account"),
    ("survey_response", "survey_question"),
    ("survey_question", "survey_answer_option"),
    ("hcp_survey", "survey_product_focus"),
    ("hcp_survey", "survey_channel")
]

# app.py
import streamlit as st
import networkx as nx
import matplotlib.pyplot as plt
import json
#from convert_csv_to_json import csv_to_json
#from relationships import crm_relationships

st.set_page_config(layout="wide")
st.title("📊 CRM Data Model Visualization")

# Load schema
schema = csv_to_json("veeva_crm_metadata.csv")

# Build graph
G = nx.DiGraph()
for table in schema:
    G.add_node(table)
for src, tgt in crm_relationships:
    G.add_edge(src, tgt)

# Draw graph
fig, ax = plt.subplots(figsize=(14, 10))
pos = nx.spring_layout(G, seed=42)
nx.draw(G, pos, with_labels=True, node_color="lightblue", edge_color="gray",
        node_size=2500, font_size=10, arrows=True)
st.pyplot(fig)

# Optional: Show column-level metadata
st.subheader("📋 Column-Level Metadata")
selected_table = st.selectbox("Select a table", list(schema.keys()))
st.json(schema[selected_table])