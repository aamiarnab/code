import streamlit as st
import pandas as pd
import fitz  # PyMuPDF
from PIL import Image
import pytesseract
import re
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
from dotenv import load_dotenv
load_dotenv()

# Initialize embedding model and ChromaDB
embedder = SentenceTransformer("all-MiniLM-L6-v2")
chroma_client = chromadb.PersistentClient(path="./shipment_db")
collection = chroma_client.get_or_create_collection(name="shipment")

# Data store for integration
shipment_data = {}

# Utility
def make_id(prefix, index):
    return f"{prefix}_{index:04d}"

def sanitize_metadata(metadata):
    return {
        k: str(v) if not isinstance(v, (bool, int, float, str)) or v is None else v
        for k, v in metadata.items()
    }

# 🧩 Shipment Log
def ingest_shipment_log(uploaded_file):
    df = pd.read_csv(uploaded_file)
    for _, row in df.iterrows():
        sid = row["ShipmentID"]
        shipment_data[sid] = {
            "shipment": dict(row),
            "invoice": None,
            "returns": [],
            "labels": []
        }
    #print ("shipment_data in ingest_shipment_log : \n", shipment_data)


# 🧾 Invoice PDF
def extract_invoice_fields(text):
    fields = {
        "invoice_id": re.search(r"Invoice #:\s*(\S+)", text),
        "date": re.search(r"Date:\s*(\S+)", text),
        "batch_id": re.search(r"Batch ID:\s*(\S+)", text),
        "product": re.search(r"Product:\s*(.+)", text),
        "quantity": re.search(r"Quantity:\s*(\d+)", text),
        "unit_price": re.search(r"Unit Price:\s*(?:INR|₹)\s*(\d+)", text),
        "total_amount": re.search(r"Total Amount:\s*(?:INR|₹)\s*(\d+)", text),
        "destination": re.search(r"Shipped To:\s*(.+)", text),
        "transport_mode": re.search(r"Transport Mode:\s*(.+)", text)
    }
    return {k: v.group(1).strip() if v else None for k, v in fields.items()}

def generate_invoice_summary(fields):
    return (
        f"Invoice {fields['invoice_id']} dated {fields['date']} for {fields['product']}, "
        f"batch {fields['batch_id']}, quantity {fields['quantity']} units, unit price ₹{fields['unit_price']}, "
        f"total ₹{fields['total_amount']}. Shipped to {fields['destination']} via {fields['transport_mode']}."
    )

def ingest_invoice(zip_file):
    import zipfile
    with zipfile.ZipFile(zip_file) as z:
        for pdf_name in z.namelist():
            if pdf_name.lower().endswith(".pdf"):
                with z.open(pdf_name) as pdf_file:
                    doc = fitz.open(stream=pdf_file.read(), filetype="pdf")
                    text = "\n".join([page.get_text() for page in doc])
                    doc.close()

                    fields = extract_invoice_fields(text)
                    invoice_id = fields.get("invoice_id")

                    for sid, data in shipment_data.items():
                        if data["shipment"].get("InvoiceID") == invoice_id:
                            data["invoice"] = fields
                            break

    #print ("shipment_data in ingest_invoice : \n", shipment_data)

# 🔁 Return Notes
def ingest_return_notes(uploaded_file):
    df = pd.read_csv(uploaded_file)
    for _, row in df.iterrows():
        sid = row["ShipmentID"]
        if sid in shipment_data:
            shipment_data[sid]["returns"].append(dict(row))
    #print ("shipment_data in ingest_return_notes : \n", shipment_data)


# 🏷️ Label Images
def extract_label_metadata(text, filename):
    batch_match = re.search(r"Batch\s*(BT\d+)", text, re.IGNORECASE)
    #handling = re.findall(r"(KEEP UPRIGHT|AVOID FREEZING|COLD CHAIN)", text, re.IGNORECASE)
    handling = re.findall(r"\b[A-Z][A-Z\s]{2,}\b", text)
    return {
        "filename": filename,
        "batch_id": batch_match.group(1) if batch_match else None,
        "handling_instructions": ", ".join(set(handling)) if handling else None,
        "ocr_text": text.strip()
    }

def ingest_label_images(zip_file):
    import zipfile
    with zipfile.ZipFile(zip_file) as z:
        for img_name in z.namelist():
            batch_id = ""
            if img_name.lower().endswith(".png"):
                with z.open(img_name) as img_file:
                    image = Image.open(img_file).convert("RGB")
                    text = pytesseract.image_to_string(image)
                    print ("image text : \n", text)
                    metadata = extract_label_metadata(text, img_name)
                    for line in text.split("\n"):
                        print("line", line)
                        if "BT" in line:
                            batch_id = line.strip()
                    #batch_id = metadata.get("batch_id")
                    print("batch_id is ", batch_id)
                    for sid, data in shipment_data.items():
                        if data["shipment"].get("BatchID") == batch_id:
                            data["labels"].append(metadata)
                            break
    #print ("shipment_data in ingest_label_images : \n", shipment_data)

# 🧠 Integrated Summary + Embedding
def generate_integrated_summary(data):
    #print ("shipment_data in at start of generated_integrated_summary : \n", shipment_data)

    shipment = data["shipment"]
    invoice = data["invoice"]
    returns = data["returns"]
    labels = data["labels"]

    summary = f"""
### Shipment Summary: {shipment['ShipmentID']}

- **Date**: {shipment['Date']}
- **Origin → Destination**: {shipment['Origin']} → {shipment['Destination']}
- **Status**: {shipment['Status']}
- **Batch ID**: {shipment['BatchID']}
- **Product**: {shipment['ProductID']} from {shipment['ProductSupplierName']}
- **Invoice ID**: {shipment.get('InvoiceID', 'N/A')}

### Invoice Details
{generate_invoice_summary(invoice) if invoice else "No invoice found."}

### Return Notes
""" + ("\n".join([f"- {r['ReturnID']}: {r['Notes']}" for r in returns]) if returns else "No return notes.") + """

### Label Instructions
""" + ("\n".join([f"- {l['handling_instructions']} (Batch: {l['batch_id']})" for l in labels]) if labels else "No label data.")

    return summary.strip()

def embed_integrated_documents():
    #print ("shipment_data in at start of embded_integrated_documents : \n", shipment_data)
    
    for i, (sid, data) in enumerate(shipment_data.items()):
        summary = generate_integrated_summary(data)
        embedding = embedder.encode(summary)
        metadata = {
            "shipment_id": sid,
            "batch_id": data["shipment"]["BatchID"],
            "invoice_id": data["shipment"].get("InvoiceID"),
            "source": "integrated"
        }
        collection.add(
            documents=[summary],
            embeddings=[embedding],
            metadatas=[sanitize_metadata(metadata)],
            ids=[make_id("shipment", i + 1)]
        )

# 🖥️ Streamlit UI
st.set_page_config(page_title="Shipment Tracker", layout="wide")
st.markdown("### 💊 Shipment Tracker")

tab1, tab2 = st.tabs(["📥 Data Preparation", "💬 Business Insight"])

with tab1:
    st.markdown("#### Prepare Shipment Knoweldge Fabric")
    uploaded_files = st.file_uploader("Upload ZIP or CSV files", type=["zip", "csv"], accept_multiple_files=True)

    if st.button("Embed All Files"):
        with st.spinner("Processing..."):
            # Step 1: Categorize files
            shipment_files = []
            invoice_files = []
            return_files = []
            label_files = []
            unknown_files = []

            for uploaded_file in uploaded_files:
                filename = uploaded_file.name.lower()
                if "shipment" in filename and filename.endswith(".csv"):
                    shipment_files.append(uploaded_file)
                elif "invoice" in filename and filename.endswith(".zip"):
                    invoice_files.append(uploaded_file)
                elif "return" in filename and filename.endswith(".csv"):
                    return_files.append(uploaded_file)
                elif "label" in filename and filename.endswith(".zip"):
                    label_files.append(uploaded_file)
                else:
                    unknown_files.append(uploaded_file)

            # Step 2: Process in correct order
            for file in shipment_files:
                ingest_shipment_log(file)
                st.success("Shipment log loaded.")

            for file in invoice_files:
                ingest_invoice(file)
                st.success("Invoices loaded.")

            for file in return_files:
                ingest_return_notes(file)
                st.success("Return notes loaded.")

            for file in label_files:
                ingest_label_images(file)
                st.success("Label images loaded.")

            for file in unknown_files:
                st.warning(f"Unrecognized file type or name: {file.name}")

            embed_integrated_documents()
            st.success(f"Embedded {len(shipment_data)} integrated shipment documents.")
        



# Tab 2 for chatbot
import os
#os.environ["GOOGLE_API_KEY"] = st.secrets["GEMINI_API_KEY"]

from langchain_google_genai import ChatGoogleGenerativeAI

llm = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash",
    temperature=0.5,
    google_api_key=os.environ["GOOGLE_API_KEY"]
)

from langchain.vectorstores import Chroma
from langchain.embeddings import HuggingFaceEmbeddings

embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

# Initialize embedding model and ChromaDB

vectorstore = Chroma(
    client=chroma_client,
    collection_name="shipment",
    embedding_function=embedding_model
)

retriever = vectorstore.as_retriever(search_kwargs={"k": 20})

from langchain.chains import RetrievalQA

qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    chain_type="stuff"
)

with tab2:
    st.markdown("#### 💬 Get Insight from Shipment Knowledge Fabric")

    user_query = st.text_input("Ask a question :")
    if user_query:
        # Step 1: Retrieve relevant documents
        retrieved_docs = retriever.get_relevant_documents(user_query)

        # Step 2: Format context for Gemini
        context = "\n\n".join([doc.page_content for doc in retrieved_docs])
        prompt = f"""You are a helpful assistant answering questions about pharmaceutical shipments, invoices, returns, and labels.

User question: {user_query}

Relevant context:
{context}

Please summarize the answer clearly. Use tables for multiple records, bullets for instructions or issues, and add commentary if needed.
If the query contains phrase like "from internet" for a supplier, then augment the output with a summary of that supplier. 
"""

        response = llm.invoke(prompt)

        # Step 3: Display Gemini response
        st.markdown("#### 🤖 Response Summary")
        st.write(response.content)


