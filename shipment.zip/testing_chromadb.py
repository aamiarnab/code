
def count_collections():
    import chromadb 
    from chromadb.config import Settings
    from sentence_transformers import SentenceTransformer


    # Initialize ChromaDB client
    embedder = SentenceTransformer("all-MiniLM-L6-v2")
    client = chromadb.PersistentClient(path="./shipment_db") 
    collections = client.list_collections()
    for collection in collections:
        collection_name = collection.name
        num_docs = collection.count()
        print(f"Collection: {collection_name}, Number of Documents: {num_docs}")
    #return collection_name, num_docs

    #client.delete_collection(name="shipment")

    collection = client.get_collection(name="shipment")
    print(collection.get(ids=['shipment_0019']))

#count_collections()

def seach_knowledge_fabric(query):
    from langchain.vectorstores import Chroma
    from langchain.embeddings import HuggingFaceEmbeddings

    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = Chroma(collection_name="shipment", embedding_function=embedding_model,persist_directory="./shipment_db") 
    #results = vectorstore.similarity_search(query=query,k=5)
    results = vectorstore.similarity_search_with_score(query=query,k=5)
    print(results)
    print("output from ChromaDB:")
    for i, doc in enumerate(results):
        print(f"\nResult {i+1}:")
        print("Content:", doc[0].page_content)
        print("Metadata:", doc[0].metadata)
        print(doc[1])

#seach_knowledge_fabric("show details of shipment SHP003")




def load_pdf():
    from langchain.document_loaders import CSVLoader, UnstructuredPDFLoader
    from langchain_community.document_loaders.image import UnstructuredImageLoader

    invoice_docs = UnstructuredPDFLoader("invoices\\invoice_001.pdf").load()
    print(invoice_docs)
    for doc in invoice_docs:
        InvoiceID = doc.page_content.split("Invoice #: ")[1][:7].strip()  
        doc.metadata["InvoiceID"] = InvoiceID
        BatchID = doc.page_content.split("Batch ID: ")[1][:6].strip()  
        doc.metadata["BatchID"] = BatchID
        print(BatchID)
    #print(docs)
#load_pdf()

